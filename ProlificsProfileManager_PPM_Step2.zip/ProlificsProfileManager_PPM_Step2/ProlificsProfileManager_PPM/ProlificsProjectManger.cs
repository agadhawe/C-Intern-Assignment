﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProlificsProfileManager
{
    class ProlificsProfileManager
    {
        public static List<Project> Projects = new List<Project>();
        public static List<Employee> Employees = new List<Employee>();
        public static List<Role> roles = new List<Role>();

        internal class Project
        {
            public string projectName { get; set; }
            public int projectId { get; set; }
            public DateTime startDate { get; set; }
            public DateTime endDate { get; set; }

            public List<Employee> Project_employees = new List<Employee>();

            public Project()
            { }

            public Project(string projectName, int projectId, DateTime startDate, DateTime endDate)
            {
                this.projectName = projectName;
                this.projectId = projectId;
                this.startDate = startDate;
                this.endDate = endDate;
                
            }

            
            public void InputProject()
            {
                Console.WriteLine("Enter the Project Name : ");
                projectName = Console.ReadLine();

                Console.WriteLine("Enter the Project ID : ");
                projectId =  Convert.ToInt32(Console.ReadLine());

                Console.WriteLine(" Enter the start date :");
                Console.WriteLine("Enter date :");
                int dd1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter month :");
                int mm1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter year :");
                int yy1 = Convert.ToInt32(Console.ReadLine());

                startDate = DateTime.Parse($"{dd1}-{mm1}-{yy1}");

                Console.WriteLine(" Enter the end date :");
                Console.WriteLine("Enter date :");
                int dd2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter month :");
                int mm2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter year :");
                int yy2 = Convert.ToInt32(Console.ReadLine());

                endDate = DateTime.Parse($"{dd2}-{mm2}-{yy2}");
            }

            public void ViewProject()
            {
                Console.WriteLine("1. Project Name : " + projectName);
                Console.WriteLine("2. Project ID : " + projectId);
                Console.WriteLine("3. Start date : " + startDate);
                Console.WriteLine("4. End date : " + endDate);
               
            }

           

            public void AddEmployeeRole(int eid)
            {

                Boolean flag = false;
                eid = Convert.ToInt32(Console.ReadLine());
                

                for (int i = 0; i < Project_employees.Count; i++)
                {
                    if (Project_employees[i].empolyeeId == eid)
                    {
                        Project_employees[i].addRoles();
                        flag = true;
                    }
                }
                if (flag == false)
                    Console.WriteLine("this employee doesnt exist in the records  ");

            }


            public void ShowAllEmployees()
            {
                Console.WriteLine(" list of all employees working  under the project are : ");
                for (int i = 0; i < Project_employees.Count; i++)
                {
                    Employee emp = Project_employees[i];
                    Console.WriteLine(" - " + emp.firstName + " " + emp.lastName);

                }
            }

            public void DeleteEmployee(int empid)
            {
                Boolean flag = false;
                for (int i = 0; i < Project_employees.Count; i++)
                {
                    Employee emp = Project_employees[i];
                    if (emp.empolyeeId == empid)
                    {
                        Project_employees.RemoveAt(i);
                        flag = true;
                        break;

                    }
                }
                if (flag == false)
                    Console.WriteLine("Employee is not found!");

            }


            public void ViewEmployeeById(int empid)
            {
                Boolean flag = false;
                for (int i = 0; i < Project_employees.Count; i++)
                {
                    Employee emp = Project_employees[i];
                    if (emp.empolyeeId == empid)
                    {
                        emp.showEmployeeDetails();
                        flag = true;
                        break;

                    }
                    if (flag == false)
                        Console.WriteLine("Employee is not found!");
                }

            }

        }

        internal class Employee
        {
            public int empolyeeId { get; set; }
            public int roleId { get; set; }
            public string firstName { get; set; }
            public string lastName { get; set; }
            public string emailId { get; set; }
            public string phoneNo { get; set; }
            public string address { get; set; }

            List<Role> Employees_roles = new List<Role>();


            
            public Employee()
            {
                try
                {
                    Console.WriteLine(" ---- Enter the employee details ----");

                    Console.WriteLine(" Enter the employee's company  Id");
                    int eid = Convert.ToInt32(Console.ReadLine());
                    empolyeeId = eid;

                    Console.WriteLine(" Enter the employee's  role-Id");
                    int rid = Convert.ToInt32(Console.ReadLine());

                    Boolean flag = false;
                    for (int i = 0; i < ProlificsProfileManager.roles.Count; i++)
                    {
                        if (rid == ProlificsProfileManager.roles[i].roleId)
                        {
                            flag = true;
                            Employees_roles.Add(ProlificsProfileManager.roles[i]);
                        }
                    }
                    if (flag == false)
                    {
                        Role role = new Role(rid);            
                        //Creating a  new class of role  
                        role.addRole();
                        Employees_roles.Add(role);
                        //adding the roles into the local list
                        ProlificsProfileManager.roles.Add(role);
                    }

                    Console.WriteLine(" Enter the employee's first name ");
                    string fname = Console.ReadLine();
                    firstName = fname;

                    Console.WriteLine(" Enter the employee's last name ");
                    string lname = Console.ReadLine();
                    lastName = lname;

                    Console.WriteLine("Enter the employee's Email Id ");
                    string email = Console.ReadLine();
                    emailId = email;

                    Console.WriteLine(" Enter the employee's contact number ");
                    string phone = Console.ReadLine();
                    phoneNo = phone;

                    Console.WriteLine(" Enter the employee's Address ");
                    string addrss = Console.ReadLine();
                    address = addrss;
                }
                catch (FormatException ex1)
                {
                    Console.WriteLine(" Please enter  proper value ");
                }

                /*catch (StackOverflowException ex2)
                {
                    Console.WriteLine(ex2.Message);
                }*/
                catch (Exception ex3)
                {
                    Console.Write(ex3.ToString());
                }
            }

            
            public Employee(int eid)
            { empolyeeId = eid; }


            
            public Employee(int eid, int rid, string fname, string lname, string email, string phone, string addresss)
            {
                empolyeeId = eid;
                roleId = rid;
                Role role = new Role(rid);
                role.addRole();
                Employees_roles.Add(role);

                firstName = fname;
                lastName = lname;
                emailId = email;
                phoneNo = phone;
                address  = addresss;

            }



            public void addRoles()
            {
                Role role = new Role(roleId);
                int role_option;
                do
                {

                    Console.WriteLine("Enter the value with respective following operations : ");
                    Console.WriteLine("1. Add Role");
                    Console.WriteLine("2. Exist");
                    role_option = Convert.ToInt32(Console.ReadLine());

                    switch (role_option)
                    {
                        case 1:
                            role.addRole();
                            break;

                        default:
                            break;

                    }


                }
                while (role_option <= 1);

            }


            public void showEmployeeBasicDetails()
            {
                Console.WriteLine("- Name : " + firstName + " " + lastName);
                Console.WriteLine("  - Roles ");
                for (int i = 0; i < Employees_roles.Count; i++)
                {
                    Employees_roles[i].viewRole();
                }
                Console.WriteLine();
            }

            public void showEmployeeDetails()
            {
                for (int i = 0; i < Employees_roles.Count; i++)
                {
                    Employees_roles[i].viewRole();
                }
                Console.WriteLine("  1.  Employee Id : " + empolyeeId);
                Console.WriteLine("  2. Name : " + firstName + " " + lastName);
                Console.WriteLine("  3. Email Id : " + emailId);
                Console.WriteLine("  4. Phone No : " + phoneNo);
                Console.WriteLine("  5. Address : " + address);
                Console.WriteLine();
            }

        }

        internal class Role
        {
            public int roleId { get; set; }
            public string roleName { get; set; }

            public List<int> roleid = new List<int>();
            public List<string> roleNames = new List<string>();
            public Role()
            {
               
                
                    Console.WriteLine("Enter the Role Id ");
                    int roleid = Convert.ToInt32(Console.ReadLine());
                    roleId = roleid;
                  
             }
                

            public Role(int roleId)
            {
                this.roleId = roleId;
                //this.roleName = roleName;
            }


            public Role(int roleId, string roleName)
            {
                this.roleId = roleId;
                this.roleName = roleName;
                roleNames.Add(roleName);
            }

            public void addRole()
            {
                Console.WriteLine(" please enter the employee's role : ");
                int role = Convert.ToInt32(Console.ReadLine());
                roleid.Add(role);
                Console.WriteLine("please enter the employee's name : ");
                 string name = Console.ReadLine();
                roleNames.Add(name);

            }




            public void viewRole()
            {

                Console.WriteLine("   Role Id : " + roleId);
                for (int i = 0; i < roleNames.Count; i++)
                {
                    Console.WriteLine("  Role Name :" + roleNames[i]);
                }
                    
            }
        }


        static void Main(string[] args)
        {
            Console.WriteLine("-------------------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("                                                                   WELCOME!!!!!!!");
            Console.WriteLine("-------------------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("Please enter the password:");
            string password = Console.ReadLine();
            int option = 0;
            if (password == "aboli123")
            {
                try
                {
                    do
                    {
                        Console.WriteLine("\n  Enter your option to perform  : ");
                        Console.WriteLine("1] Add Project");
                        Console.WriteLine("2] View Projects");
                        Console.WriteLine("3] Add Employees");
                        Console.WriteLine("4] View Employees");
                        Console.WriteLine("5] Add Role");
                        Console.WriteLine("6] View Roles");
                        Console.WriteLine("7] Add Employee to project ");
                        Console.WriteLine("8] Delete Employee from project");
                        Console.WriteLine("9] View Project Detail ( all Project Details and List of employees ) : ");
                        Console.WriteLine("10] Logout");
                        try
                        {
                            option = Convert.ToInt32(Console.ReadLine());
                        }

                        catch (FormatException ex1)
                        {
                            Console.WriteLine("Inavalid , enter numeric value ");
                        }

                        catch (StackOverflowException ex2)
                        {
                            Console.WriteLine("Invalid , enter single digit numeric value ");
                        }
                        catch (Exception ex)
                        {
                            Console.Write(ex.ToString());
                        }


                        switch (option)
                        {


                            case 1:   //Add project
                                Project project = new Project();
                                project.InputProject();
                                Projects.Add(project);
                                Console.WriteLine();
                                break;



                            case 2:    //view projects 
                                Console.WriteLine("Project list : ");
                                for (int j = 0; j < Projects.Count; j++)
                                {
                                    Projects[j].ViewProject();
                                }
                                Console.WriteLine();
                                break;



                            case 3:    //Add Employee
                                Employee employee = new Employee();
                                Employees.Add(employee);
                                Console.WriteLine();
                                break;



                            case 4:   //View employees
                                Console.WriteLine(" Employee's list : ");

                                for (int j = 0; j < Employees.Count; j++)
                                {
                                    Employees[j].showEmployeeDetails();
                                }
                                Console.WriteLine();
                                break;



                            case 5:    //Add role 
                                Role role = new Role();
                                roles.Add(role);
                                Console.WriteLine();
                                break;



                            case 6:   //View roles
                                Console.WriteLine(" Roles list : ");

                                for (int j = 0; j < roles.Count; j++)
                                {
                                    roles[j].viewRole();
                                }
                                Console.WriteLine();
                                break;

                            case 7: // add employee to the project 
                                
                                Console.WriteLine("Enter the Project Name ");
                                string pname = Console.ReadLine();
                                Boolean flag = false;
                                for (int j = 0; j < Projects.Count; j++)
                                {
                                    if (Projects[j].projectName == pname)
                                    {
                                        flag = true;
                                        
                                        Console.Write(" Enter the Employee ID : ");
                                        int eid = 0;
                                        try
                                        {
                                            eid = Convert.ToInt32(Console.ReadLine());
                                        }
                                        catch (FormatException ex1)
                                        {
                                            Console.WriteLine("Inalid , enter numeric value ");
                                        }

                                        catch (StackOverflowException ex2)
                                        {
                                            Console.WriteLine("Invalid, enter single digit numeric value ");
                                        }
                                        catch (Exception ex3)
                                        {
                                            Console.Write(ex3.ToString());
                                        }

                                        Boolean flag01 = false;
                                        for (int k = 0; k < Employees.Count; k++)
                                        {
                                            if (Employees[k].empolyeeId == eid)
                                            {
                                                Projects[j].Project_employees.Add(Employees[k]);
                                                flag01 = true;


                                                // displaying employees working on a project 
                                                Console.WriteLine("\n list of employees in the project :");
                                                Projects[j].ShowAllEmployees();
                                            }
                                        }
                                        if (flag01 == false)
                                        {
                                            Console.WriteLine("Employee company ID not found");
                                        }


                                    }
                                }
                                if (!flag)
                                    Console.WriteLine(" Project doesnt exist ");

                                break;


                            case 8: // delete employee from the project 
                               
                                Console.WriteLine("Enter the Project Name ");
                                string pname1 = null;
                                try
                                {
                                    pname1 = Console.ReadLine();

                                    Boolean flag1 = false;
                                    for (int j = 0; j < Projects.Count; j++)
                                    {
                                        if (Projects[j].projectName == pname1)
                                        {
                                            Console.WriteLine("Enter the employee company ID,  to  be removed from the project");
                                            int eid = Convert.ToInt32(Console.ReadLine());
                                            Projects[j].DeleteEmployee(eid);
                                            flag1 = true;

                                            
                                            Console.WriteLine("\n list of employees in the project  ");
                                            Projects[j].ShowAllEmployees();
                                        }
                                    }
                                    if (flag1 == false)
                                        Console.WriteLine(" Project doesnt exist  ");
                                }

                                catch (FormatException ex1)
                                {
                                    Console.WriteLine("Invalid , enter numeric value ");
                                }

                                catch (StackOverflowException ex2)
                                {
                                    Console.WriteLine("Inavlid, enter single digit numeric value");
                                }
                                catch (Exception ex3)
                                {
                                    Console.Write(ex3.ToString());
                                }
                                break;



                            case 9:
                                Console.WriteLine("Projects Detail are : ");
                                for (int j = 0; j < Projects.Count; j++)
                                {
                                    Console.WriteLine(" o  Name Of Project : " + Projects[j].projectName);
                                    Console.WriteLine(" o  Employees Detail are : ");
                                    Projects[j].ShowAllEmployees();


                                }
                                break;



                            case 10:
                                Console.WriteLine("Thankyou!!!!!!!!");
                                Console.WriteLine("Session logout");
                                break;

                            default:
                                break;
                        }
                    }

                    while (option <= 9);
                    Console.ReadLine();
                }

                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
           
        }
    }


}
    

