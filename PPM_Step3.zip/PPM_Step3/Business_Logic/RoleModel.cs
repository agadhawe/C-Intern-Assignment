﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Logic
{
     public class RoleModel
    {

        public int roleId { get; set; }
        public string roleName { get; set; }

        public RoleModel()
        { }

        public RoleModel(int roleId, string roleName)
        {
            this.roleId = roleId;
         
            this.roleName = roleName;

        }

    }

}

