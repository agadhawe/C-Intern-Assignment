﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Logic
{
    public class ProjectBL 
    {
        public List<ProjectModel> Projects = new List<ProjectModel>();
        public ProjectBL()
        {

        }

        public void AddProject(ProjectModel projectModel)
        {
            Projects.Add(projectModel);
        }

        public List<ProjectModel> ReturnProjectList()
        {
            return Projects;
        }

        public bool IsProject(int pid)
        {
            for (int i = 0; i < Projects.Count; i++)
            {
                if (pid == Projects[i].projectId)
                {
                    return true;
                }
            }
            return false;
        }
        public void AddEmployeeToProject(int pid, EmployeeModel emp)
        {
            for (int i = 0; i < Projects.Count; i++)
            {
                if (pid == Projects[i].projectId)
                {
                    Projects[i].ProjectEmployees.Add(emp);
                    break;
                }
            }
        }

    

        public void DeleteEmployeeToProject(int pid, EmployeeModel emp)
        {
            for (int i = 0; i < Projects.Count; i++)
            {
                if (pid == Projects[i].projectId)
                {
                    Projects[i].ProjectEmployees.Remove(emp);
                    break;
                }
            }
        }

    }
}
