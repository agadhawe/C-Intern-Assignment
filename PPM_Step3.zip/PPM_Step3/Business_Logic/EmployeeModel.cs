﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Logic;

namespace Bussiness_Logic
{
    public class EmployeeModel
    {

        public int employeeId { get; set; }
        public int roleId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string emailId { get; set; }
        public string phoneNo { get; set; }
        public string address { get; set; }

        public RoleModel role = new RoleModel();

        public EmployeeModel() { 
        }
        public EmployeeModel(int employeeid, int roleid, string firstname, string lastname, string email, string phoneno, string Address)
        {
            this.employeeId = employeeid;
            this.roleId = roleid;
            this.firstName = firstname;
            this.lastName = lastname;
            this.emailId = email;
            this.phoneNo = phoneno;
            this.address = Address;

        }

        
    }
}
