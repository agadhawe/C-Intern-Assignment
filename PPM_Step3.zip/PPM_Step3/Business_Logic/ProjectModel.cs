﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Logic;

namespace Bussiness_Logic
{
    public class ProjectModel 
    {
        public string projectName { get; set; }
        public int projectId { get; set; }
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }


        public List<EmployeeModel> ProjectEmployees = new List<EmployeeModel>();

        public ProjectModel()
        {
        }

        public ProjectModel( string projectName, int ProjectId, DateTime startDate, DateTime endDate)
        {
            this.projectName = projectName;
            this.projectId = ProjectId;
            this.startDate = startDate;
            this.endDate = endDate;
            
        }
    }
}
