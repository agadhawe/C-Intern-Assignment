﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Logic;

namespace Bussiness_Logic
{
     public class EmployeeBL
    {
     
            public List<EmployeeModel> Employees = new List<EmployeeModel>();
            public void AddEmployee(EmployeeModel employee)
            {
                Employees.Add(employee);
            }

            public List<EmployeeModel> ReturnEmployee()
            {
                return Employees;
            }

            public bool IsEmployee(int empid)
            {
                for (int i = 0; i < Employees.Count; i++)
                {
                    if (empid == Employees[i].employeeId)
                    {
                        return true;
                    }
                }
                return false;
            }

            public EmployeeModel GetEmployeeById(int empid)
            {
                EmployeeModel emp = new EmployeeModel();
                for (int i = 0; i < Employees.Count; i++)
                {
                    if (empid == Employees[i].employeeId)
                    {
                        emp = Employees[i];
                        return emp;
                    }
                }
                return emp;
            }


        }
    }
