﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Logic;

namespace Bussiness_Logic
{
     public class EmployeeBL
    {
     
            public List<EmployeeModel> Employees = new List<EmployeeModel>();
            public void AddEmployee(EmployeeModel employee)
            {
                Employees.Add(employee);
            }

            public List<EmployeeModel> ReturnEmployeeList()
            {
                return Employees;
            }

            public void AssignRoleToEmployee(int eid, RoleModel role)
            {
                for (int i = 0; i < Employees.Count; i++)
                {
                    if (Employees[i].employeeId == eid)
                    {
                        Employees[i].SetRole(role);
                    }

                }

            }

            public bool IsEmployee(int eid)
            {
                for (int i = 0; i < Employees.Count; i++)
                {
                    if (eid == Employees[i].employeeId)
                    {
                        return true;
                    }
                }
                return false;
            }

            public EmployeeModel GetEmployeeById(int eid)
            {
                EmployeeModel emp = new EmployeeModel();
                for (int i = 0; i < Employees.Count; i++)
                {
                    if (eid == Employees[i].employeeId)
                    {
                        emp = Employees[i];
                        return emp;
                    }
                }
                return emp;
            }


        }
    }
