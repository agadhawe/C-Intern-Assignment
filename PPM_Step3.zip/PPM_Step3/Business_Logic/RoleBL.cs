﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Bussiness_Logic
{
     public class RoleBL 
    {
        public List<RoleModel> Roles = new List<RoleModel>();

        public RoleBL()
        { }

        public void AddRole(RoleModel role)
        {
            Roles.Add(role);
        }

        public List<RoleModel> ReturnRoleList()
        {
            return Roles;
        }
        public bool IsRole(int rid)
        {
            for (int i = 0; i < Roles.Count; i++)
            {
                if (rid == Roles[i].roleId)
                {
                    return true;
                }
            }
            return false;
        }
        public RoleModel GetRoleById(int rid)
        {
            RoleModel role = new RoleModel();
            for (int i = 0; i < Roles.Count; i++)
            {
                if (rid == Roles[i].roleId)
                {
                    role = Roles[i];
                    return role;
                }
            }
            return role;
        }


    }
}
