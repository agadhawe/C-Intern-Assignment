﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Logic;


namespace PPM_Step4
{
    class Program
    {


        static void Main(string[] args)
        {
            ProjectUI project = new ProjectUI();
            ProjectBL projectBL = new ProjectBL();
            EmployeeUI employee = new EmployeeUI();
            EmployeeBL employeeBL = new EmployeeBL();
            RoleUI role = new RoleUI();
            RoleBL roleBL = new RoleBL();
            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine("                WELCOME TO PROLIFICS");
            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine("Please enter the password:");
            string password = Console.ReadLine();
            int option = '0';
            if (password == "aboli")
            {
                try
                {
                    do
                    {

                        Console.WriteLine("\n                     MAIN MENU ");
                        Console.WriteLine("1] Add Project");
                        Console.WriteLine("2] View Projects");
                        Console.WriteLine("3] Add Role");
                        Console.WriteLine("4] View Roles");
                        Console.WriteLine("5] Add Employees ");
                        Console.WriteLine("6] View Employees");
                        Console.WriteLine("7] Adding an Employee to project ");
                        Console.WriteLine("8] Delete an Employee from project");
                        Console.WriteLine("9] View Project Details  ");
                        Console.WriteLine("10] Quit");


                        try
                        {
                            option = Convert.ToInt32(Console.ReadLine());
                        
                        }
                        catch (Exception ex)
                        {
                            Console.Write(ex.ToString());
                        }


                        switch (option)
                        {
                            case 1:

                                projectBL.AddProject(project.AddProject());
                                Console.WriteLine();
                                break;

                            case 2:

                                project.ViewProject(projectBL.ReturnProject());
                                Console.WriteLine();
                                break;

                            case 3:

                                roleBL.AddRole(role.AddRole());
                                Console.WriteLine();
                                break;

                            case 4:

                                role.ViewRole(roleBL.ReturnRole());
                                Console.WriteLine();
                                break;

                            case 5:

                                employeeBL.AddEmployee(employee.AddEmployee());
                                Console.WriteLine();
                                break;

                            case 6:

                                employee.ViewEmployeeList(employeeBL.ReturnEmployee());
                                Console.WriteLine();
                                break;

                            case 7:

                                Console.WriteLine("Enter the Project-ID :");
                                int pid = Convert.ToInt32(Console.ReadLine());
                                if (projectBL.IsProject(pid))
                                {
                                    Console.WriteLine("Enter the Employee-ID :");
                                    int eid = Convert.ToInt32(Console.ReadLine());
                                    if (employeeBL.IsEmployee(eid))
                                    {
                                        EmployeeModel emp = employeeBL.GetEmployeeById(eid);
                                        projectBL.AddEmployeeToProject(pid, emp);
                                        Console.WriteLine("Employee Added Successfully!");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Employee's id doesnt match");
                                        break;
                                    }
                                }
                                else
                                {
                                    Console.WriteLine(" Project doesnt exist");
                                    break;
                                }

                                break;


                            case 8:

                                Console.WriteLine("Enter the Project-Name :");
                                int pid1 = Convert.ToInt32(Console.ReadLine());
                                if (projectBL.IsProject(pid1))
                                {
                                    Console.WriteLine("Enter the Employee-ID :");
                                    int eid1 = Convert.ToInt32(Console.ReadLine());
                                    if (employeeBL.IsEmployee(eid1))
                                    {
                                        EmployeeModel emp = employeeBL.GetEmployeeById(eid1);
                                        projectBL.DeleteEmployeeFromProject(pid1, emp);
                                        Console.WriteLine("Employee Deleted Successfully!");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Employee's id doesnt match ");
                                        break;
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Project doesnt exist");
                                    break;
                                }

                                break;

                            case 9:

                                project.ViewProjectWithEmployees(projectBL.ReturnProject());

                                break;


                            case 10:
                                Console.WriteLine("Thankyou!!");
                                Console.WriteLine("Session LOGOUT");

                                break;

                            default:
                                break;
                        }
                    }

                    while (option <= 10);
                    Console.ReadLine();
                }

                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }
        }


    }
}