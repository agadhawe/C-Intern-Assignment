﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Logic;

namespace PPM_Step4
{
    class RoleUI 
    {
        public RoleModel AddRole()
        {
            RoleModel rm = new RoleModel();
            try
            {
                Console.WriteLine(" Provide the Roleid");
                rm.roleId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine(" Provide Employee's Role ");
                rm.roleName = Console.ReadLine();
               
            }

            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }


            return rm;
        }

        public void ViewRole(List<RoleModel> roles)
        {
            try
            {
                for (int i = 0; i < roles.Count; i++)
                {
                    Console.WriteLine("\n Role Id : " + roles[i].roleId);
                    Console.WriteLine(" Role Name : " + roles[i].roleName);
                   
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }



        }
    }
}
