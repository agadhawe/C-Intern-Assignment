﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Logic;

namespace PPM_Step4
{
    class RoleUI 
    {
        public RoleModel AddRole()
        {
            RoleModel rm = new RoleModel();
            try
            {
                Console.WriteLine(" Provide the Roleid");
                rm.roleId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine(" Provide Employee's Role ");
                rm.roleName = Console.ReadLine();
               
            }
            catch (FormatException ex1)
            {
                Console.WriteLine("Invalid, enter numeric value");
                Console.WriteLine(ex1.Message);
            }

            catch (StackOverflowException ex2)
            {
                Console.WriteLine("Invalid, single digit value to be entered");
                Console.WriteLine(ex2.Message);
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }


            return rm;
        }

        public void ViewRole(List<RoleModel> roles)
        {
            try
            {
                for (int i = 0; i < roles.Count; i++)
                {
                    Console.WriteLine("\n Role Id : " + roles[i].roleId);
                    Console.WriteLine(" Role Name : " + roles[i].roleName);
                   
                }
            }
            catch (FormatException ex1)
            {
                Console.WriteLine("Invalid ,enter numeric value");
                Console.WriteLine(ex1.Message);
            }

            catch (StackOverflowException ex2)
            {
                Console.WriteLine("Invalid , single value to be entered");
                Console.WriteLine(ex2.Message);
            }
            catch (Exception ex3)
            {
                Console.Write(ex3.ToString());
            }



        }
    }
}
