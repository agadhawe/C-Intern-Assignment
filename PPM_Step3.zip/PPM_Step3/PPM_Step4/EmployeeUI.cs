﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Logic;

namespace PPM_Step4
{
    class EmployeeUI

    {
        public EmployeeUI()
        {

        }
        public EmployeeModel AddEmployee()
        {
            EmployeeModel em = new EmployeeModel();
            try
            {

                Console.WriteLine(" Provide Employee's company  Id");
                int eid = Convert.ToInt32(Console.ReadLine());
                em.employeeId = eid;

                Console.WriteLine(" Provide Employee's role Id");
                int rid = Convert.ToInt32(Console.ReadLine());
                em.roleId = rid;

                Console.WriteLine(" Provide Employee's First name ");
                string fname = Console.ReadLine();
                em.firstName = fname;

                Console.WriteLine(" Provide Employee's Last name ");
                string lname = Console.ReadLine();
                em.lastName = lname;

                Console.WriteLine("Provide Employee's Company email Id ");
                string email = Console.ReadLine();
                em.emailId = email;

                Console.WriteLine(" Provide Employee's contact number ");
                string phone = Console.ReadLine();
                em.phoneNo = phone;

                Console.WriteLine(" Provide Employee's Address ");
                string addrss = Console.ReadLine();
                em.address = addrss;
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }
            return em;
        }

        public void ViewEmployeeList(List<EmployeeModel> employees)
        {
            for (int i = 0; i < employees.Count; i++)
            {
                Console.WriteLine("\n Employee's company Id " + employees[i].employeeId);
                Console.WriteLine(" Employee's role Id " + employees[i].roleId);
                Console.WriteLine("   Name : " + employees[i].firstName + " " + employees[i].lastName);
                Console.WriteLine("   Email Id : " + employees[i].emailId);
                Console.WriteLine("   Contact number : " + employees[i].phoneNo);
                Console.WriteLine("   Address : " + employees[i].address);
            }

        }
    }
}

