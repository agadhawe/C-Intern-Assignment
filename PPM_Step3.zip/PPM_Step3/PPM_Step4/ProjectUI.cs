﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bussiness_Logic;

namespace PPM_Step4
{
    class ProjectUI
    {
        public ProjectUI()
        {

        }

        public ProjectModel AddProject()
        {
            ProjectModel pm = new ProjectModel();
            try
            {

                Console.WriteLine("Enter the Project Name : ");
                pm.projectName = Console.ReadLine();

                Console.WriteLine("Enter the Project ID : ");
                pm.projectId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the start date in project");
                Console.WriteLine("Enter date");
                int dd1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter month");
                int mm1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter year");
                int yy1 = Convert.ToInt32(Console.ReadLine());

                pm.startDate = DateTime.Parse($"{dd1}-{mm1}-{yy1}");

                Console.WriteLine("Enter the end date in project");
                Console.WriteLine("Enter date");
                int dd2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter month");
                int mm2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter year");
                int yy2 = Convert.ToInt32(Console.ReadLine());

                pm.endDate = DateTime.Parse($"{dd2}-{mm2}-{yy2}");

            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }
            return pm;
        }

        public void AddEmployeeToProject()
        {
            try
            {
                Console.WriteLine("Enter the Project-Name :");
                string pname = Console.ReadLine();

                Console.WriteLine("Enter the Employee-ID :");
                int eid = Convert.ToInt32(Console.ReadLine());

            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }
        }

       
        public void ViewProject(List<ProjectModel> projectModels)
        {

            for (int i = 0; i < projectModels.Count; i++)
            {

                Console.WriteLine("\n  Name Of Project = " + projectModels[i].projectName);
                Console.WriteLine("  Project ID = " + projectModels[i].projectId);
                Console.WriteLine("  Start date = " + projectModels[i].startDate);
                Console.WriteLine("  End date = " + projectModels[i].endDate);


            }
        }

        public void ViewProjectWithEmployees(List<ProjectModel> projectModels)
        {
            Console.WriteLine("\n- Project Details are :");
            for (int i = 0; i < projectModels.Count; i++)
            {
                Console.WriteLine("\n   Project ID = " + projectModels[i].projectId);
                Console.WriteLine("   Name Of Project = " + projectModels[i].projectName);
                Console.WriteLine("  Employees working on the project : ");
                for (int j = 0; j < projectModels[i].ProjectEmployees.Count; j++)
                {
                    Console.WriteLine("   " + projectModels[i].ProjectEmployees[j].firstName +
                        " " + projectModels[i].ProjectEmployees[j].lastName);


                }

            }


        }
    }
}
