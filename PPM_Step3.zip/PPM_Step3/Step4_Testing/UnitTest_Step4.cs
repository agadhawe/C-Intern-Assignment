﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Bussiness_Logic;
using PPM_Step4;
using System.Collections.Generic;

namespace Step4_Testing
{
    [TestClass]
    public class UnitTest_Step4
    {
        //[SetUp]


        ProjectBL projectBLtesting = new ProjectBL();
        EmployeeBL employeeBLtesting = new EmployeeBL();
        RoleBL roleBLtesting = new RoleBL();
        List<ProjectModel> projects;
        List<EmployeeModel> employees;
        List<RoleModel> roles;

        [TestMethod]

        public void Project_Test_Equal ()
        {
            //ARRANGE
            DateTime sd1 = new DateTime(22, 12, 21);
            DateTime ed1 = new DateTime(19, 5, 22);
            ProjectModel project1 = new ProjectModel( "prolifics manager",101,sd1,ed1);


            //ACT
            projectBLtesting.AddProject(project1);
            projects = projectBLtesting.ReturnProjectList();


            //ASSERT
            Assert.AreEqual(true, projectBLtesting.IsProject(101));
          

        }
        [TestMethod]
        public void Project_Test_NotEqual()
        {
            //ARRANGE
            DateTime sd1 = new DateTime(21, 11, 21);
            DateTime ed1 = new DateTime(18, 2, 22);
            ProjectModel project1 = new ProjectModel("banking system", 102, sd1, ed1);

            //ACT
            projectBLtesting.AddProject(project1);
            projects = projectBLtesting.ReturnProjectList();

            //ASSERT
           
            Assert.AreEqual(false, projectBLtesting.IsProject(103));
        }
        [TestMethod]
        public void Role_Test_Equal()
        {
            //ARRANGE
            RoleModel role1 = new RoleModel(1, "trainee");
            

            //ACT
            roleBLtesting.AddRole(role1);
           
            roles = roleBLtesting.ReturnRoleList();

            //ASSERT
            Assert.AreEqual(1, role1.roleId);
            Assert.AreEqual("trainee", role1.roleName);

           
            Assert.AreEqual(true, roleBLtesting.IsRole(role1.roleId));
          
        }
        [TestMethod]
        public void Role_Test_NotEqual()
        {
            //ARRANGE
            
            RoleModel role1 = new RoleModel(5, "tester");

            //ACT
            
            roleBLtesting.AddRole(role1);
            roles = roleBLtesting.ReturnRoleList();

            //ASSERT
            

            Assert.AreEqual(5, role1.roleId);
            //Assert.AreEqual("techincal engineer", role1.roleName);
            Assert.AreNotEqual(false, roleBLtesting.IsRole(role1.roleId));
        }
        [TestMethod]
        public void Employee_Test_Equal()
        {
            //Arrange
            EmployeeModel employee1 = new EmployeeModel(1,1,"aboli","gadwe","aboli@gmail.com","1234567890","raheja house");


            //Act
            employeeBLtesting.AddEmployee(employee1);
            employees = employeeBLtesting.ReturnEmployeeList();

            //Assert
            Assert.AreEqual(1, employee1.employeeId);
            Assert.AreEqual(1, employee1.roleId);

            Assert.AreEqual(true, employeeBLtesting.IsEmployee(employee1.employeeId));
            Assert.AreEqual(false, employeeBLtesting.IsEmployee(4));
        }
        [TestMethod]
        public void Employee_Test_NotEqual()
        {
            //ARRANGE
            EmployeeModel employee1 = new EmployeeModel(1, 1, "aboli", "gadwe", "aboli@gmail.com", "1234567890", "raheja house");
            

            //ACT
            employeeBLtesting.AddEmployee(employee1);
            
            employees = employeeBLtesting.ReturnEmployeeList();

            //ASSERT
            Assert.AreEqual(1, employee1.employeeId);
            Assert.AreEqual(1, employee1.roleId);

            Assert.AreEqual(true, employeeBLtesting.IsEmployee(employee1.employeeId));
            Assert.AreNotEqual(true, employeeBLtesting.IsEmployee(3));
        }
        [TestMethod]
        public void Add_Employee_To_Project_Test()
        {
            //ARRANGE
            DateTime sd1 = new DateTime(20, 12, 20);
            DateTime ed1 = new DateTime(20, 12, 21);
            ProjectModel project1 = new ProjectModel("banking system ", 1, sd1, ed1);

            EmployeeModel employee1 = new EmployeeModel(3, 4, "sarita", "gadwe", "sarita@gmail.com", "1234567890", "dattaraya nagar");

            //ACT
            projectBLtesting.AddProject(project1);

            projectBLtesting.AddEmployeeToProject(1, employee1);

            projects = projectBLtesting.ReturnProjectList();

            //ASSERT
            Assert.AreEqual(employee1, projects[0].ProjectEmployees[0]);
        }

             [TestMethod]
               public void Delete_Employee_To_Project_Test() {

                   //ARRANGE
                   DateTime sd1 = new DateTime(20, 12, 20);
                   DateTime ed1 = new DateTime(20, 12, 21);
                   ProjectModel project1 = new ProjectModel("banking system ", 1, sd1, ed1);
                   EmployeeModel employee1 = new EmployeeModel(1, 1, "aboli", "gadwe", "aboli@gmail.com", "1234567890", "raheja house");
                   EmployeeModel employee2 = new EmployeeModel(3, 4, "sarita", "gadwe", "sarita@gmail.com", "1234567890", "dattaraya nagar");

                   //ACT
                   projectBLtesting.AddProject(project1);
                   projectBLtesting.AddEmployeeToProject(1, employee1);
                   projectBLtesting.AddEmployeeToProject(1, employee2);

                   projects = projectBLtesting.ReturnProjectList();
                   projectBLtesting.DeleteEmployeeToProject(1, employee2);
                   projects = projectBLtesting.ReturnProjectList();

                   //ASSERT
                   Assert.AreEqual(employee1, projects[0].ProjectEmployees[0]);

               }
        }
   
}

